"""Logika przypadków użycia: wolne terminy (UC02), rezerwacja (UC03),
odwołanie (UC04), walidacja PESEL (FR-01), wyznaczanie terminów z grafiku."""
from datetime import datetime, timedelta

from sqlalchemy.exc import IntegrityError

from models import (db, GodzinyPrzyjec, Pacjent, Rejestratorka, StatusWizyty,
                    Termin, Wizyta)


class BladOperacji(Exception):
    """Wyjątek z przypadku użycia; kod odpowiada wyjątkom z opisów UC.
    `wizyta` - wizyta, której dotyczy błąd (np. istniejąca wizyta w UC03.0.E2)."""
    def __init__(self, kod, komunikat, wizyta=None):
        super().__init__(komunikat)
        self.kod = kod
        self.komunikat = komunikat
        self.wizyta = wizyta


# ---------- FR-01: PESEL ----------

def pesel_poprawny(pesel):
    """Sprawdza format (11 cyfr) i sumę kontrolną numeru PESEL."""
    if not pesel or len(pesel) != 11 or not pesel.isdigit():
        return False
    wagi = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    suma = sum(int(c) * w for c, w in zip(pesel[:10], wagi))
    return (10 - suma % 10) % 10 == int(pesel[10])


# ---------- UC06 (pomocniczo): godziny przyjęć -> terminy ----------

def wyznacz_terminy(blok: GodzinyPrzyjec):
    """Dzieli blok godzin przyjęć na terminy o długości dlugosc_wizyty_min."""
    start = datetime.combine(blok.data, blok.godzina_od)
    koniec_bloku = datetime.combine(blok.data, blok.godzina_do)
    krok = timedelta(minutes=blok.dlugosc_wizyty_min)
    while start + krok <= koniec_bloku:
        blok.terminy.append(Termin(poczatek=start, koniec=start + krok))
        start += krok


# ---------- UC02: wolne terminy ----------

def wolne_terminy(lekarz_id, od, do, teraz=None):
    """Terminy z grafiku lekarza w zakresie [od, do], bez zarezerwowanych,
    zablokowanych i przeszłych (AC-03)."""
    teraz = teraz or datetime.now()
    zajete = (db.select(Wizyta.termin_id)
              .where(Wizyta.status == StatusWizyty.ZAPLANOWANA))
    return (Termin.query
            .join(GodzinyPrzyjec)
            .filter(GodzinyPrzyjec.lekarz_id == lekarz_id,
                    GodzinyPrzyjec.data >= od,
                    GodzinyPrzyjec.data <= do,
                    Termin.zablokowany.is_(False),
                    Termin.poczatek > teraz,
                    Termin.id.not_in(zajete))
            .order_by(Termin.poczatek)
            .all())


def najblizszy_wolny_termin(lekarz_id, po_dniu, teraz=None):
    """UC02.2: pierwszy wolny termin lekarza po końcu szukanego zakresu (albo None)."""
    teraz = teraz or datetime.now()
    zajete = (db.select(Wizyta.termin_id)
              .where(Wizyta.status == StatusWizyty.ZAPLANOWANA))
    return (Termin.query
            .join(GodzinyPrzyjec)
            .filter(GodzinyPrzyjec.lekarz_id == lekarz_id,
                    GodzinyPrzyjec.data > po_dniu,
                    Termin.zablokowany.is_(False),
                    Termin.poczatek > teraz,
                    Termin.id.not_in(zajete))
            .order_by(Termin.poczatek)
            .first())


def mozna_odwolac(wizyta, uzytkownik, teraz=None):
    """Czy użytkownik może teraz odwołać wizytę (R4: limit 24 h dla pacjenta)."""
    teraz = teraz or datetime.now()
    if wizyta.status != StatusWizyty.ZAPLANOWANA:
        return False
    if isinstance(uzytkownik, Rejestratorka):
        return True
    return wizyta.termin.poczatek - teraz >= timedelta(hours=24)


def oznacz_odbyte(teraz=None):
    """Przejście stanu ZAPLANOWANA -> ODBYTA: wizyty, których termin już minął.
    Wywoływane przy otwieraniu list wizyt, więc nie potrzeba osobnego zadania w tle."""
    teraz = teraz or datetime.now()
    minione = db.select(Termin.id).where(Termin.koniec <= teraz)
    zmienione = (Wizyta.query
                 .filter(Wizyta.status == StatusWizyty.ZAPLANOWANA,
                         Wizyta.termin_id.in_(minione))
                 .update({Wizyta.status: StatusWizyty.ODBYTA}, synchronize_session=False))
    if zmienione:
        db.session.commit()
    return zmienione


# ---------- UC03 / UC07: rezerwacja ----------

def zarezerwuj_wizyte(pacjent_id, termin_id, rejestratorka_id=None, teraz=None):
    teraz = teraz or datetime.now()

    pacjent = db.session.get(Pacjent, pacjent_id)
    if pacjent is None:
        raise BladOperacji("BRAK_PACJENTA", "Nie ma takiego pacjenta.")

    termin = db.session.get(Termin, termin_id)
    if termin is None:
        raise BladOperacji("BRAK_TERMINU", "Nie ma takiego terminu.")

    # R3: nie da się zarezerwować terminu zablokowanego ani przeszłego
    if termin.zablokowany or termin.poczatek <= teraz:
        raise BladOperacji("TERMIN_NIEDOSTEPNY", "Ten termin jest niedostępny.")

    # R1 / UC03.0.E1: termin zajęty przez inną zaplanowaną wizytę
    zajety = Wizyta.query.filter_by(termin_id=termin.id,
                                    status=StatusWizyty.ZAPLANOWANA).first()
    if zajety:
        raise BladOperacji("TERMIN_ZAJETY", "Ten termin został już zarezerwowany. Wybierz inny.")

    # R2 / UC03.0.E2: pacjent ma już nadchodzącą wizytę u tego lekarza (FR-06)
    lekarz_id = termin.godziny_przyjec.lekarz_id
    juz_ma = (Wizyta.query
              .join(Termin).join(GodzinyPrzyjec)
              .filter(Wizyta.pacjent_id == pacjent.id,
                      Wizyta.status == StatusWizyty.ZAPLANOWANA,
                      Termin.poczatek > teraz,
                      GodzinyPrzyjec.lekarz_id == lekarz_id)
              .first())
    if juz_ma:
        raise BladOperacji("WIZYTA_U_LEKARZA_ISTNIEJE",
                           "Masz już zaplanowaną wizytę u tego lekarza.", wizyta=juz_ma)

    wizyta = Wizyta(pacjent_id=pacjent.id, termin_id=termin.id,
                    rejestratorka_id=rejestratorka_id)
    db.session.add(wizyta)
    try:
        db.session.commit()
    except IntegrityError:
        # dwa żądania naraz: oba przeszły sprawdzenie wyżej, ale indeks
        # uq_termin_jedna_zaplanowana w bazie przepuścił tylko pierwsze
        db.session.rollback()
        raise BladOperacji("TERMIN_ZAJETY", "Ten termin został już zarezerwowany. Wybierz inny.")
    return wizyta


# ---------- UC04: odwołanie ----------

def odwolaj_wizyte(wizyta_id, uzytkownik, teraz=None):
    teraz = teraz or datetime.now()
    wizyta = db.session.get(Wizyta, wizyta_id)
    if wizyta is None:
        raise BladOperacji("BRAK_WIZYTY", "Nie ma takiej wizyty.")

    jest_rejestratorka = isinstance(uzytkownik, Rejestratorka)

    # R5 / UC04.0.E2: pacjent odwołuje tylko własne wizyty
    if not jest_rejestratorka and wizyta.pacjent_id != uzytkownik.id:
        raise BladOperacji("BRAK_DOSTEPU", "To nie jest twoja wizyta.")

    if wizyta.status != StatusWizyty.ZAPLANOWANA:
        raise BladOperacji("NIE_DO_ODWOLANIA", "Tej wizyty nie można już odwołać.")

    # R4 / UC04.0.E1: limit 24 h (nie dotyczy rejestratorki, UC04.2)
    if not mozna_odwolac(wizyta, uzytkownik, teraz):
        raise BladOperacji("ZA_POZNO",
                           "Wizytę można odwołać najpóźniej 24 h przed terminem. "
                           "Zadzwoń do rejestracji.", wizyta=wizyta)

    wizyta.status = StatusWizyty.ODWOLANA
    wizyta.data_odwolania = teraz
    db.session.commit()
    return wizyta
