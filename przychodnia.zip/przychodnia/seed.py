"""Dane testowe: specjalizacje, lekarze z grafikiem na 14 dni, pacjent i rejestratorka.
Uruchom:  python seed.py   (usuwa i tworzy bazę od nowa)"""
from datetime import date, datetime, time, timedelta

from app import create_app
from logika import wyznacz_terminy
from models import (db, GodzinyPrzyjec, Lekarz, Pacjent, Rejestratorka,
                    Specjalizacja, StatusWizyty, Termin, Wizyta)

LEKARZE = [
    ("Anna", "Nowak", "Internista", "anna.nowak@przychodnia.pl", time(8), time(12)),
    ("Piotr", "Zieliński", "Kardiolog", "piotr.zielinski@przychodnia.pl", time(12), time(16)),
    ("Magdalena", "Wójcik", "Pediatra", "magdalena.wojcik@przychodnia.pl", time(9), time(13)),
    ("Tomasz", "Kamiński", "Dermatolog", "tomasz.kaminski@przychodnia.pl", time(14), time(18)),
]


def zasiej():
    db.drop_all()
    db.create_all()

    for i, (imie, nazwisko, spec, email, od, do) in enumerate(LEKARZE, start=1):
        s = Specjalizacja(nazwa=spec)
        lek = Lekarz(imie=imie, nazwisko=nazwisko, email=email,
                     numer_pwz=f"{1234560 + i}", specjalizacja=s)
        lek.ustaw_haslo("lekarz123")
        db.session.add(lek)
        for d in range(15):
            dzien = date.today() + timedelta(days=d)
            if dzien.weekday() >= 5:      # bez weekendów
                continue
            blok = GodzinyPrzyjec(lekarz=lek, data=dzien, godzina_od=od,
                                  godzina_do=do, dlugosc_wizyty_min=20)
            wyznacz_terminy(blok)
            db.session.add(blok)

    p = Pacjent(imie="Jan", nazwisko="Kowalski", email="jan@test.pl",
                telefon="600100200", pesel="90010112349")
    p.ustaw_haslo("pacjent123")
    inni = [Pacjent(imie=i, nazwisko=n, email=e, telefon=t, pesel=ps)
            for i, n, e, t, ps in [
                ("Ewa", "Lewandowska", "ewa@test.pl", "601200300", "85050554327"),
                ("Marek", "Dąbrowski", "marek@test.pl", "602300400", "02070803628"),
                ("Zofia", "Szymańska", "zofia@test.pl", None, "75121512347")]]
    for o in inni:
        o.ustaw_haslo("pacjent123")
    r = Rejestratorka(imie="Ewa", nazwisko="Mazur", email="rejestracja@przychodnia.pl")
    r.ustaw_haslo("rejestracja123")
    db.session.add_all([p, r, *inni])
    db.session.commit()

    # Przykładowe wizyty, żeby widoki nie były puste na pokazie
    anna = Lekarz.query.filter_by(email="anna.nowak@przychodnia.pl").one()
    piotr = Lekarz.query.filter_by(email="piotr.zielinski@przychodnia.pl").one()

    def termin(lekarz, dzien, godz, minuta=0):
        return (Termin.query.join(GodzinyPrzyjec)
                .filter(GodzinyPrzyjec.lekarz_id == lekarz.id,
                        Termin.poczatek == datetime.combine(dzien, time(godz, minuta)))
                .one())

    # najbliższy dzień roboczy (dziś lub później) - wizyty u dr Nowak
    dzien = date.today()
    while dzien.weekday() >= 5:
        dzien += timedelta(days=1)
    for pacjent, (g, m) in zip(inni, [(10, 0), (10, 40), (11, 20)]):
        db.session.add(Wizyta(pacjent=pacjent, termin=termin(anna, dzien, g, m)))

    # Jan: nadchodząca wizyta u kardiologa za ok. tydzień
    za_tydzien = dzien + timedelta(days=7)
    db.session.add(Wizyta(pacjent=p, termin=termin(piotr, za_tydzien, 13, 0)))

    # Jan: historia - wizyta odbyta i odwołana (blok sprzed dwóch tygodni)
    dawno = date.today() - timedelta(days=14)
    while dawno.weekday() >= 5:
        dawno -= timedelta(days=1)
    blok = GodzinyPrzyjec(lekarz=anna, data=dawno, godzina_od=time(8),
                          godzina_do=time(12), dlugosc_wizyty_min=20)
    wyznacz_terminy(blok)
    db.session.add(blok)
    db.session.flush()
    db.session.add_all([
        Wizyta(pacjent=p, termin=blok.terminy[3], status=StatusWizyty.ODBYTA),
        Wizyta(pacjent=p, termin=blok.terminy[1], status=StatusWizyty.ODWOLANA,
               data_odwolania=datetime.combine(dawno - timedelta(days=3), time(18))),
    ])
    db.session.commit()


if __name__ == "__main__":
    with create_app().app_context():
        zasiej()
    print("Baza utworzona. Konta testowe:")
    print("  pacjent:       jan@test.pl / pacjent123")
    print("  lekarz:        anna.nowak@przychodnia.pl / lekarz123")
    print("  rejestratorka: rejestracja@przychodnia.pl / rejestracja123")
