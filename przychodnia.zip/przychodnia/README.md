# Przychodnia – rejestracja online

Aplikacja Flask + SQLite do internetowej rejestracji na wizyty.

## Uruchomienie

```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
python seed.py                 # tworzy bazę z danymi testowymi
python app.py                  # start: http://127.0.0.1:5000
```

## Konta testowe

| Rola          | E-mail                       | Hasło          |
|---------------|------------------------------|----------------|
| Pacjent       | jan@test.pl                  | pacjent123     |
| Lekarz        | anna.nowak@przychodnia.pl    | lekarz123      |
| Rejestratorka | rejestracja@przychodnia.pl   | rejestracja123 |

## Testy

```bash
python -m pytest -v tests        # 23 testy kryteriów akceptacji (AC-xx)
```

Test obciążeniowy (NFR-01), przy działającej aplikacji:

```bash
pip install locust
locust -f locustfile.py --host http://127.0.0.1:5000 --headless -u 50 -r 5 -t 2m --csv wyniki
```

## Co działa (przypadki użycia z planu projektu)

| UC   | Nazwa                          | Status        |
|------|--------------------------------|---------------|
| UC01 | Załóż konto                    | gotowe        |
| UC02 | Sprawdź wolne terminy          | gotowe        |
| UC03 | Zarezerwuj wizytę              | gotowe        |
| UC04 | Odwołaj wizytę                 | gotowe (pacjent) |
| UC05 | Przeglądaj moje wizyty         | gotowe        |
| UC06 | Zarządzaj grafikiem lekarza    | do zrobienia (grafik na razie z seed.py) |
| UC07 | Zarejestruj pacjenta na wizytę | do zrobienia  |
| UC08 | Wyświetl wizyty na dzień       | gotowe        |

E-maile z potwierdzeniem i przypomnieniem (FR-13) – do zrobienia.

## Struktura

- `models.py` – klasy z modelu domeny (SQLAlchemy)
- `logika.py` – logika przypadków użycia: wolne terminy, rezerwacja, odwołanie, PESEL
- `app.py` – widoki (adresy) Flaska, logowanie i role
- `seed.py` – dane testowe
- `templates/`, `static/` – strony HTML i styl
- `tests/` – testy kryteriów akceptacji (AC-xx)
- `locustfile.py` – test obciążeniowy (NFR-01)
