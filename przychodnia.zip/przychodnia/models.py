"""Klasy modelu domeny (diagram klas) jako modele SQLAlchemy."""
import enum
from datetime import datetime

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()


class StatusWizyty(enum.Enum):
    ZAPLANOWANA = "ZAPLANOWANA"
    ODWOLANA = "ODWOLANA"
    ODBYTA = "ODBYTA"


class Uzytkownik(UserMixin, db.Model):
    """Klasa abstrakcyjna z modelu; podklasy w jednej tabeli (kolumna typ)."""
    __tablename__ = "uzytkownik"
    id = db.Column(db.Integer, primary_key=True)
    imie = db.Column(db.String(50), nullable=False)
    nazwisko = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    telefon = db.Column(db.String(20))
    haslo_hash = db.Column(db.String(255))  # NFR-02: tylko hash, nigdy jawne hasło
    typ = db.Column(db.String(20), nullable=False)
    __mapper_args__ = {"polymorphic_on": typ}

    def ustaw_haslo(self, haslo):
        self.haslo_hash = generate_password_hash(haslo)

    def sprawdz_haslo(self, haslo):
        return self.haslo_hash is not None and check_password_hash(self.haslo_hash, haslo)

    @property
    def pelne_imie(self):
        return f"{self.imie} {self.nazwisko}"


class Pacjent(Uzytkownik):
    pesel = db.Column(db.String(11), unique=True)
    wizyty = db.relationship("Wizyta", back_populates="pacjent",
                             foreign_keys="Wizyta.pacjent_id")
    __mapper_args__ = {"polymorphic_identity": "pacjent"}


class Lekarz(Uzytkownik):
    numer_pwz = db.Column(db.String(10))
    specjalizacja_id = db.Column(db.Integer, db.ForeignKey("specjalizacja.id"))
    specjalizacja = db.relationship("Specjalizacja", back_populates="lekarze")
    godziny_przyjec = db.relationship("GodzinyPrzyjec", back_populates="lekarz")
    __mapper_args__ = {"polymorphic_identity": "lekarz"}


class Rejestratorka(Uzytkownik):
    __mapper_args__ = {"polymorphic_identity": "rejestratorka"}


class Specjalizacja(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nazwa = db.Column(db.String(80), unique=True, nullable=False)
    lekarze = db.relationship("Lekarz", back_populates="specjalizacja")


class GodzinyPrzyjec(db.Model):
    __tablename__ = "godziny_przyjec"
    id = db.Column(db.Integer, primary_key=True)
    lekarz_id = db.Column(db.Integer, db.ForeignKey("uzytkownik.id"), nullable=False)
    data = db.Column(db.Date, nullable=False)
    godzina_od = db.Column(db.Time, nullable=False)
    godzina_do = db.Column(db.Time, nullable=False)
    dlugosc_wizyty_min = db.Column(db.Integer, nullable=False, default=15)
    lekarz = db.relationship("Lekarz", back_populates="godziny_przyjec")
    terminy = db.relationship("Termin", back_populates="godziny_przyjec",
                              cascade="all, delete-orphan")


class Termin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    godziny_przyjec_id = db.Column(db.Integer, db.ForeignKey("godziny_przyjec.id"),
                                   nullable=False)
    poczatek = db.Column(db.DateTime, nullable=False)
    koniec = db.Column(db.DateTime, nullable=False)
    zablokowany = db.Column(db.Boolean, nullable=False, default=False)
    godziny_przyjec = db.relationship("GodzinyPrzyjec", back_populates="terminy")
    wizyty = db.relationship("Wizyta", back_populates="termin")

    @property
    def lekarz(self):
        return self.godziny_przyjec.lekarz


class Wizyta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pacjent_id = db.Column(db.Integer, db.ForeignKey("uzytkownik.id"), nullable=False)
    termin_id = db.Column(db.Integer, db.ForeignKey("termin.id"), nullable=False)
    rejestratorka_id = db.Column(db.Integer, db.ForeignKey("uzytkownik.id"))  # 0..1
    status = db.Column(db.Enum(StatusWizyty), nullable=False,
                       default=StatusWizyty.ZAPLANOWANA)
    data_utworzenia = db.Column(db.DateTime, nullable=False, default=datetime.now)
    data_odwolania = db.Column(db.DateTime)
    przypomnienie_wyslane = db.Column(db.Boolean, nullable=False, default=False)

    pacjent = db.relationship("Pacjent", back_populates="wizyty", foreign_keys=[pacjent_id])
    termin = db.relationship("Termin", back_populates="wizyty")

    # Reguła R1 (FR-05) pilnowana też przez bazę: jeden termin = najwyżej
    # jedna wizyta ZAPLANOWANA. Odwołane wizyty zostają w historii terminu.
    __table_args__ = (
        db.Index("uq_termin_jedna_zaplanowana", "termin_id", unique=True,
                 sqlite_where=db.text("status = 'ZAPLANOWANA'")),
    )
