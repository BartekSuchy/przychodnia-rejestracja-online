"""Testy kryteriów akceptacji z planu projektu (AC-xx)."""
from datetime import date, datetime, timedelta

import pytest
from sqlalchemy.exc import IntegrityError

from conftest import zaloguj
from logika import BladOperacji, odwolaj_wizyte, pesel_poprawny, wolne_terminy
from models import (db, Lekarz, Pacjent, Rejestratorka, StatusWizyty, Termin,
                    Uzytkownik, Wizyta)


def id_lekarza(email="lekarz@p.pl"):
    return Lekarz.query.filter_by(email=email).one().id


def id_pacjenta(email):
    return Pacjent.query.filter_by(email=email).one().id


def terminy_lekarza(email="lekarz@p.pl"):
    od = date.today()
    return wolne_terminy(id_lekarza(email), od, od + timedelta(days=14))


# ---------- AC-01: zakładanie konta ----------

def test_ac01_zalozenie_konta_i_logowanie(client):
    r = client.post("/rejestracja", data={
        "imie": "Adam", "nazwisko": "Lis", "pesel": "02070803628",
        "email": "adam@p.pl", "telefon": "", "haslo": "tajnehaslo"})
    assert r.status_code == 302
    r = zaloguj(client, "adam@p.pl", "tajnehaslo")
    assert r.status_code == 302 and "/logowanie" not in r.headers["Location"]


def test_ac01_zajety_email(client):
    r = client.post("/rejestracja", data={
        "imie": "X", "nazwisko": "Y", "pesel": "02070803628",
        "email": "jan@p.pl", "telefon": "", "haslo": "tajnehaslo"})
    assert r.status_code == 400
    assert "już istnieje".encode() in r.data


def test_ac01_zly_pesel(client):
    r = client.post("/rejestracja", data={
        "imie": "X", "nazwisko": "Y", "pesel": "12345678901",
        "email": "nowy@p.pl", "telefon": "", "haslo": "tajnehaslo"})
    assert r.status_code == 400
    assert Uzytkownik.query.filter_by(email="nowy@p.pl").first() is None


def test_pesel_suma_kontrolna():
    assert pesel_poprawny("90010112349")
    assert not pesel_poprawny("90010112340")
    assert not pesel_poprawny("123")


# ---------- AC-03 / AC-04: wolne terminy i rezerwacja ----------

def test_ac03_ac04_zarezerwowany_termin_znika_z_wolnych(client):
    wolne = terminy_lekarza()
    assert len(wolne) == 3
    zaloguj(client, "jan@p.pl")
    r = client.post(f"/rezerwuj/{wolne[0].id}")
    assert r.status_code == 302
    assert wolne[0].id not in [t.id for t in terminy_lekarza()]


def test_zablokowany_termin_nie_jest_wolny(app):
    t = terminy_lekarza()[0]
    t.zablokowany = True
    db.session.commit()
    assert t.id not in [x.id for x in terminy_lekarza()]


def test_rezerwacja_wymaga_logowania(client):
    t = terminy_lekarza()[0]
    r = client.post(f"/rezerwuj/{t.id}")
    assert r.status_code == 302 and "/logowanie" in r.headers["Location"]


# ---------- AC-05: zajęty termin ----------

def test_ac05_zajety_termin_odrzucony(client):
    t = terminy_lekarza()[0]
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    client.get("/wyloguj")
    zaloguj(client, "ewa@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    assert Wizyta.query.filter_by(termin_id=t.id).count() == 1
    assert Wizyta.query.one().pacjent_id == id_pacjenta("jan@p.pl")


def test_ac05_baza_blokuje_podwojna_rezerwacje(app):
    t = terminy_lekarza()[0]
    db.session.add(Wizyta(pacjent_id=id_pacjenta("jan@p.pl"), termin_id=t.id))
    db.session.commit()
    db.session.add(Wizyta(pacjent_id=id_pacjenta("ewa@p.pl"), termin_id=t.id))
    with pytest.raises(IntegrityError):
        db.session.commit()


# ---------- AC-06: jedna wizyta u lekarza ----------

def test_ac06_druga_wizyta_u_tego_samego_lekarza(client):
    t1, t2, _ = terminy_lekarza()
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t1.id}")
    client.post(f"/rezerwuj/{t2.id}")
    assert Wizyta.query.count() == 1


def test_ac06_u_innego_lekarza_mozna(client):
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{terminy_lekarza()[0].id}")
    client.post(f"/rezerwuj/{terminy_lekarza('lekarz2@p.pl')[0].id}")
    assert Wizyta.query.count() == 2


# ---------- AC-07 / AC-08: odwołanie ----------

def test_ac07_odwolanie_zwalnia_termin(client):
    t = terminy_lekarza()[0]
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    w = Wizyta.query.one()
    client.post(f"/wizyty/{w.id}/odwolaj")
    assert db.session.get(Wizyta, w.id).status == StatusWizyty.ODWOLANA
    assert t.id in [x.id for x in terminy_lekarza()]


def test_ac07_odwolanie_ponizej_24h_odrzucone(app):
    t = terminy_lekarza()[0]
    db.session.add(Wizyta(pacjent_id=id_pacjenta("jan@p.pl"), termin_id=t.id))
    db.session.commit()
    w = Wizyta.query.one()
    pacjent = db.session.get(Pacjent, id_pacjenta("jan@p.pl"))
    za_malo_czasu = t.poczatek - timedelta(hours=5)
    with pytest.raises(BladOperacji) as e:
        odwolaj_wizyte(w.id, pacjent, teraz=za_malo_czasu)
    assert e.value.kod == "ZA_POZNO"
    # rejestratorki limit 24 h nie dotyczy (UC04.2)
    rej = Rejestratorka.query.one()
    odwolaj_wizyte(w.id, rej, teraz=za_malo_czasu)
    assert w.status == StatusWizyty.ODWOLANA


def test_ac08_cudza_wizyta_403(client):
    t = terminy_lekarza()[0]
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    w = Wizyta.query.one()
    client.get("/wyloguj")
    zaloguj(client, "ewa@p.pl")
    r = client.post(f"/wizyty/{w.id}/odwolaj")
    assert r.status_code == 403
    assert db.session.get(Wizyta, w.id).status == StatusWizyty.ZAPLANOWANA


# ---------- AC-09: moje wizyty ----------

def test_ac09_moje_wizyty_tylko_wlasne(client):
    t1 = terminy_lekarza()[0]
    t2 = terminy_lekarza("lekarz2@p.pl")[0]
    db.session.add_all([Wizyta(pacjent_id=id_pacjenta("jan@p.pl"), termin_id=t1.id),
                        Wizyta(pacjent_id=id_pacjenta("ewa@p.pl"), termin_id=t2.id)])
    db.session.commit()
    zaloguj(client, "jan@p.pl")
    html = client.get("/moje-wizyty").data.decode()
    assert "Anna Nowak" in html and "Piotr Zieliński" not in html


# ---------- AC-12: widok lekarza ----------

def test_ac12_lekarz_widzi_swoje_wizyty(client):
    t1 = terminy_lekarza()[0]
    t2 = terminy_lekarza("lekarz2@p.pl")[0]
    db.session.add_all([Wizyta(pacjent_id=id_pacjenta("jan@p.pl"), termin_id=t1.id),
                        Wizyta(pacjent_id=id_pacjenta("ewa@p.pl"), termin_id=t2.id)])
    db.session.commit()
    zaloguj(client, "lekarz@p.pl", "lekarz123")
    html = client.get(f"/lekarz/dzien?data={t1.poczatek.date().isoformat()}").data.decode()
    assert "Jan Kowalski" in html and "Ewa Nowak" not in html


def test_pacjent_nie_wejdzie_do_widoku_lekarza(client):
    zaloguj(client, "jan@p.pl")
    assert client.get("/lekarz/dzien").status_code == 403


# ---------- AC-15: hasło tylko jako hash ----------

def test_ac15_haslo_nie_jest_jawne(app):
    u = Pacjent.query.filter_by(email="jan@p.pl").one()
    assert u.haslo_hash != "pacjent123" and u.sprawdz_haslo("pacjent123")


# ---------- UC04.0 krok 3: potwierdzenie odwołania ----------

def test_uc04_get_pokazuje_potwierdzenie_i_niczego_nie_zmienia(client):
    t = terminy_lekarza()[0]
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    w = Wizyta.query.one()
    r = client.get(f"/wizyty/{w.id}/odwolaj")
    assert r.status_code == 200
    assert "Na pewno odwołać".encode() in r.data
    assert db.session.get(Wizyta, w.id).status == StatusWizyty.ZAPLANOWANA


def test_uc04_potwierdzenie_cudzej_wizyty_403(client):
    t = terminy_lekarza()[0]
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t.id}")
    w = Wizyta.query.one()
    client.get("/wyloguj")
    zaloguj(client, "ewa@p.pl")
    assert client.get(f"/wizyty/{w.id}/odwolaj").status_code == 403


# ---------- UC03.0.E2: pokazanie istniejącej wizyty ----------

def test_uc03_e2_pokazuje_istniejaca_wizyte_i_propozycje_odwolania(client):
    t1, t2, _ = terminy_lekarza()
    zaloguj(client, "jan@p.pl")
    client.post(f"/rezerwuj/{t1.id}")
    w = Wizyta.query.one()
    r = client.post(f"/rezerwuj/{t2.id}")
    html = r.data.decode()
    assert r.status_code == 409
    assert t1.poczatek.strftime("%H:%M") in html
    assert f"/wizyty/{w.id}/odwolaj" in html


# ---------- UC02.2: najbliższy wolny termin ----------

def test_uc02_2_pokazuje_najblizszy_wolny_termin(client):
    lid = id_lekarza()
    dzis = date.today().isoformat()       # terminy w danych testowych są pojutrze
    html = client.get(f"/terminy?lekarz_id={lid}&od={dzis}&do={dzis}").data.decode()
    assert "Najbliższy wolny termin" in html
    assert "10:00" in html


# ---------- stan ODBYTA (diagram stanów wizyty) ----------

def test_wizyta_po_terminie_staje_sie_odbyta(app):
    from logika import oznacz_odbyte
    t = terminy_lekarza()[0]
    db.session.add(Wizyta(pacjent_id=id_pacjenta("jan@p.pl"), termin_id=t.id))
    db.session.commit()
    assert oznacz_odbyte(teraz=t.koniec - timedelta(minutes=1)) == 0   # jeszcze trwa
    assert oznacz_odbyte(teraz=t.koniec + timedelta(minutes=1)) == 1
    w = Wizyta.query.one()
    assert w.status == StatusWizyty.ODBYTA
    pacjent = db.session.get(Pacjent, id_pacjenta("jan@p.pl"))
    with pytest.raises(BladOperacji):                                 # odbytej nie da się odwołać
        odwolaj_wizyte(w.id, pacjent, teraz=t.koniec + timedelta(minutes=1))
