import sys
from datetime import date, datetime, time, timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import create_app  # noqa: E402
from logika import wyznacz_terminy  # noqa: E402
from models import (db, GodzinyPrzyjec, Lekarz, Pacjent, Rejestratorka,  # noqa: E402
                    Specjalizacja)


@pytest.fixture
def app():
    app = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "TESTING": True})
    with app.app_context():
        db.drop_all()
        db.create_all()
        jutro = date.today() + timedelta(days=2)
        lek = Lekarz(imie="Anna", nazwisko="Nowak", email="lekarz@p.pl",
                     specjalizacja=Specjalizacja(nazwa="Internista"))
        lek.ustaw_haslo("lekarz123")
        lek2 = Lekarz(imie="Piotr", nazwisko="Zieliński", email="lekarz2@p.pl",
                      specjalizacja=Specjalizacja(nazwa="Kardiolog"))
        lek2.ustaw_haslo("lekarz123")
        for l in (lek, lek2):
            blok = GodzinyPrzyjec(lekarz=l, data=jutro, godzina_od=time(10),
                                  godzina_do=time(11), dlugosc_wizyty_min=20)
            wyznacz_terminy(blok)                       # 3 terminy: 10:00, 10:20, 10:40
            db.session.add(blok)
        p1 = Pacjent(imie="Jan", nazwisko="Kowalski", email="jan@p.pl", pesel="90010112349")
        p2 = Pacjent(imie="Ewa", nazwisko="Nowak", email="ewa@p.pl", pesel="85050554327")
        r = Rejestratorka(imie="Ola", nazwisko="Mazur", email="rej@p.pl")
        for u in (p1, p2):
            u.ustaw_haslo("pacjent123")
        r.ustaw_haslo("rejestracja123")
        db.session.add_all([lek, lek2, p1, p2, r])
        db.session.commit()
        yield app


@pytest.fixture
def client(app):
    return app.test_client()


def zaloguj(client, email, haslo="pacjent123"):
    return client.post("/logowanie", data={"email": email, "haslo": haslo})
