"""
Test obciążeniowy dla NFR-01 / AC-14:
95% zapytań o wolne terminy ma się kończyć w czasie poniżej 2 s
przy 50 równoczesnych użytkownikach.

Uruchomienie (w osobnym terminalu musi działać aplikacja: python app.py):

    pip install locust
    locust -f locustfile.py --host http://127.0.0.1:5000 --headless -u 50 -r 5 -t 2m --csv wyniki

Wynik: plik wyniki_stats.csv, wiersz "/terminy [szukaj]", kolumna "95%" (w ms) ma być < 2000.
Bez --headless Locust pokazuje wykresy pod http://localhost:8089
"""
import random
import re
from datetime import date, timedelta

from locust import HttpUser, between, task

EMAIL = "jan@test.pl"        # konto z seed.py
HASLO = "pacjent123"


class Pacjent(HttpUser):
    wait_time = between(1, 3)    # pauza między akcjami, jak u prawdziwej osoby

    def on_start(self):
        self.client.post("/logowanie", data={"email": EMAIL, "haslo": HASLO})
        # identyfikatory lekarzy bierzemy z listy na stronie, nie wpisujemy na sztywno
        strona = self.client.get("/terminy").text
        self.lekarze = re.findall(r'<option value="(\d+)"', strona) or ["1"]

    @task(1)
    def lista_lekarzy(self):
        self.client.get("/terminy", name="/terminy [lista lekarzy]")

    @task(3)
    def wolne_terminy(self):
        od = date.today()
        self.client.get(
            "/terminy",
            params={"lekarz_id": random.choice(self.lekarze),
                    "od": od.isoformat(), "do": (od + timedelta(days=14)).isoformat()},
            name="/terminy [szukaj]",
        )
