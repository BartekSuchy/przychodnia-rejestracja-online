"""Przychodnia – rejestracja online. Aplikacja Flask."""
from datetime import date, datetime, timedelta
from functools import wraps
from itertools import groupby

from flask import (Flask, abort, flash, redirect, render_template, request,
                   url_for)
from flask_login import (LoginManager, current_user, login_required,
                         login_user, logout_user)

from logika import (BladOperacji, mozna_odwolac, najblizszy_wolny_termin,
                    odwolaj_wizyte, oznacz_odbyte, pesel_poprawny, wolne_terminy,
                    zarezerwuj_wizyte)
from models import (db, GodzinyPrzyjec, Lekarz, Pacjent, Specjalizacja,
                    StatusWizyty, Termin, Uzytkownik, Wizyta)

login_manager = LoginManager()
login_manager.login_view = "logowanie"
login_manager.login_message = "Zaloguj się, aby kontynuować."


@login_manager.user_loader
def wczytaj_uzytkownika(uid):
    return db.session.get(Uzytkownik, int(uid))


def wymaga_roli(rola):
    """Dekorator: dostęp tylko dla użytkownika o danej roli (pacjent/lekarz/rejestratorka)."""
    def dekorator(f):
        @wraps(f)
        @login_required
        def opakowanie(*args, **kwargs):
            if current_user.typ != rola:
                abort(403)
            return f(*args, **kwargs)
        return opakowanie
    return dekorator


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY="zmien-mnie-na-produkcji",
        SQLALCHEMY_DATABASE_URI="sqlite:///przychodnia.db",
        TELEFON_REJESTRACJI="22 100 20 30",   # przykładowy numer (UC04.0.E1)
    )
    if config:
        app.config.update(config)

    db.init_app(app)
    login_manager.init_app(app)

    @app.context_processor
    def dane_dla_szablonow():
        return {"telefon_rejestracji": app.config["TELEFON_REJESTRACJI"]}

    @app.template_filter("dzien")
    def format_dnia(d):
        dni = ["poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"]
        return f"{dni[d.weekday()]}, {d.strftime('%d.%m.%Y')}"

    @app.template_filter("status_pl")
    def status_po_polsku(status):
        return {"ZAPLANOWANA": "zaplanowana", "ODWOLANA": "odwołana",
                "ODBYTA": "odbyta"}[status.value]

    # ---------- strona główna ----------
    @app.route("/")
    def start():
        if current_user.is_authenticated and current_user.typ == "lekarz":
            return redirect(url_for("lekarz_dzien"))
        return redirect(url_for("szukaj_terminu"))

    # ---------- logowanie ----------
    @app.route("/logowanie", methods=["GET", "POST"])
    def logowanie():
        if request.method == "POST":
            u = Uzytkownik.query.filter_by(email=request.form["email"].strip().lower()).first()
            if u and u.sprawdz_haslo(request.form["haslo"]):
                login_user(u)
                return redirect(request.args.get("next") or url_for("start"))
            flash("Nieprawidłowy e-mail lub hasło.", "blad")
        return render_template("logowanie.html")

    @app.route("/wyloguj")
    def wyloguj():
        logout_user()
        return redirect(url_for("logowanie"))

    # ---------- UC01: Załóż konto ----------
    @app.route("/rejestracja", methods=["GET", "POST"])
    def rejestracja():
        dane = request.form
        if request.method == "POST":
            bledy = []
            email = dane["email"].strip().lower()
            if not all(dane.get(p, "").strip() for p in ("imie", "nazwisko", "email", "pesel", "haslo")):
                bledy.append("Wypełnij wszystkie wymagane pola.")
            if not pesel_poprawny(dane["pesel"].strip()):
                bledy.append("Niepoprawny numer PESEL.")                       # UC01.0.E2
            if Uzytkownik.query.filter_by(email=email).first():
                bledy.append("Konto z tym adresem e-mail już istnieje.")      # UC01.0.E1
            elif Pacjent.query.filter_by(pesel=dane["pesel"].strip()).first():
                bledy.append("Konto z tym numerem PESEL już istnieje.")
            if len(dane["haslo"]) < 8:
                bledy.append("Hasło musi mieć co najmniej 8 znaków.")
            if bledy:
                for b in bledy:
                    flash(b, "blad")
                return render_template("rejestracja.html", dane=dane), 400
            p = Pacjent(imie=dane["imie"].strip(), nazwisko=dane["nazwisko"].strip(),
                        email=email, telefon=dane.get("telefon", "").strip(),
                        pesel=dane["pesel"].strip())
            p.ustaw_haslo(dane["haslo"])
            db.session.add(p)
            db.session.commit()
            flash("Konto zostało utworzone. Możesz się zalogować.", "ok")
            return redirect(url_for("logowanie"))
        return render_template("rejestracja.html", dane={})

    # ---------- UC02: Sprawdź wolne terminy ----------
    @app.route("/terminy")
    def szukaj_terminu():
        lekarze = Lekarz.query.order_by(Lekarz.nazwisko).all()
        lekarz_id = request.args.get("lekarz_id", type=int)
        od = request.args.get("od", type=date.fromisoformat) or date.today()
        do = request.args.get("do", type=date.fromisoformat) or od + timedelta(days=14)
        lekarz, dni, najblizszy = None, [], None
        if lekarz_id:
            lekarz = db.session.get(Lekarz, lekarz_id) or abort(404)
            if do < od:                                                        # UC02.0.E1
                flash("Data końcowa nie może być wcześniejsza niż początkowa.", "blad")
            else:
                terminy = wolne_terminy(lekarz_id, od, do)
                dni = [(d, list(t)) for d, t in groupby(terminy, key=lambda t: t.poczatek.date())]
                if not dni:                                                    # UC02.2
                    najblizszy = najblizszy_wolny_termin(lekarz_id, do)
        return render_template("terminy.html", lekarze=lekarze, lekarz=lekarz,
                               dni=dni, od=od, do=do, najblizszy=najblizszy)

    # ---------- UC03: Zarezerwuj wizytę ----------
    @app.route("/rezerwuj/<int:termin_id>", methods=["GET", "POST"])
    @wymaga_roli("pacjent")
    def rezerwuj(termin_id):
        termin = db.session.get(Termin, termin_id) or abort(404)
        if request.method == "POST":
            try:
                zarezerwuj_wizyte(current_user.id, termin.id)
            except BladOperacji as e:
                if e.kod == "WIZYTA_U_LEKARZA_ISTNIEJE":                       # UC03.0.E2
                    return render_template("juz_masz_wizyte.html", wizyta=e.wizyta,
                                           mozna_odwolac=mozna_odwolac(e.wizyta, current_user)), 409
                flash(e.komunikat, "blad")                                     # UC03.0.E1
                return redirect(url_for("szukaj_terminu", lekarz_id=termin.lekarz.id))
            flash("Wizyta zarezerwowana.", "ok")
            return redirect(url_for("moje_wizyty"))
        return render_template("potwierdz.html", termin=termin)

    # ---------- UC05: Przeglądaj moje wizyty ----------
    @app.route("/moje-wizyty")
    @wymaga_roli("pacjent")
    def moje_wizyty():
        oznacz_odbyte()
        wizyty = (Wizyta.query.join(Termin)
                  .filter(Wizyta.pacjent_id == current_user.id)
                  .order_by(Termin.poczatek).all())
        teraz = datetime.now()
        nadchodzace = [w for w in wizyty
                       if w.termin.poczatek >= teraz and w.status == StatusWizyty.ZAPLANOWANA]
        przeszle = [w for w in reversed(wizyty) if w not in nadchodzace]
        return render_template("moje_wizyty.html", nadchodzace=nadchodzace,
                               przeszle=przeszle,
                               mozna_odwolac=lambda w: mozna_odwolac(w, current_user))

    # ---------- UC04: Odwołaj wizytę ----------
    @app.route("/wizyty/<int:wizyta_id>/odwolaj", methods=["GET", "POST"])
    @login_required
    def odwolaj(wizyta_id):
        if request.method == "GET":                                           # UC04.0 krok 3
            wizyta = db.session.get(Wizyta, wizyta_id) or abort(404)
            if current_user.typ != "rejestratorka" and wizyta.pacjent_id != current_user.id:
                abort(403)                                                    # AC-08
            if not mozna_odwolac(wizyta, current_user):
                flash(f"Wizytę można odwołać najpóźniej 24 h przed terminem. "
                      f"Zadzwoń do rejestracji: {app.config['TELEFON_REJESTRACJI']}.", "blad")
                return redirect(url_for("moje_wizyty"))
            return render_template("odwolaj.html", wizyta=wizyta)
        try:
            odwolaj_wizyte(wizyta_id, current_user)
        except BladOperacji as e:
            if e.kod == "BRAK_DOSTEPU":
                abort(403)                                                    # AC-08
            if e.kod == "BRAK_WIZYTY":
                abort(404)
            komunikat = e.komunikat
            if e.kod == "ZA_POZNO":                                           # UC04.0.E1
                komunikat = komunikat.replace(
                    "Zadzwoń do rejestracji.",
                    f"Zadzwoń do rejestracji: {app.config['TELEFON_REJESTRACJI']}.")
            flash(komunikat, "blad")
        else:
            flash("Wizyta została odwołana. Termin jest znowu wolny.", "ok")
        return redirect(url_for("moje_wizyty"))

    # ---------- UC08: Wyświetl wizyty na dzień ----------
    @app.route("/lekarz/dzien")
    @wymaga_roli("lekarz")
    def lekarz_dzien():
        dzien = request.args.get("data", type=date.fromisoformat) or date.today()
        oznacz_odbyte()
        wizyty = (Wizyta.query.join(Termin).join(GodzinyPrzyjec)
                  .filter(GodzinyPrzyjec.lekarz_id == current_user.id,
                          GodzinyPrzyjec.data == dzien,
                          Wizyta.status != StatusWizyty.ODWOLANA)
                  .order_by(Termin.poczatek).all())
        return render_template("lekarz_dzien.html", dzien=dzien, wizyty=wizyty,
                               timedelta=timedelta)

    @app.errorhandler(403)
    def brak_dostepu(e):
        return render_template("blad.html", kod=403,
                               opis="Nie masz dostępu do tej strony."), 403

    @app.errorhandler(404)
    def nie_znaleziono(e):
        return render_template("blad.html", kod=404,
                               opis="Nie znaleziono strony."), 404

    with app.app_context():
        db.create_all()
    return app


if __name__ == "__main__":
    create_app().run(debug=True)
